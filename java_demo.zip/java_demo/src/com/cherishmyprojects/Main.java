package com.cherishmyprojects;

public class Main {
import java.util.Scanner;

    public static void main(String[] args) {
        System.out.println("Hello again");
    }
}
